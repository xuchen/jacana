#! /usr/bin/env python
import re


# <A 1 >

keep = set()
pattern = re.compile("<A (\d+) >")
f = open('Train1-2393.Negative-M.POSInput')
for line in f:
    if line.startswith("<A "):
        m = pattern.match(line.strip())
        keep.add(m.group(1))
f.close()


#<Q 1 >
#Who is the author of the book , `` The Iron Lady : A Biography of Margaret Thatcher '' ?
#</Q>

write = False
pattern = re.compile("<Q (\d+) >")
f = open('Train1-2393.Question.POSInput.orig')
out_f = open('Train1-2393.Question.POSInput', 'w')
for line in f:
    if line.startswith("<Q"):
        m = pattern.match(line.strip())
        if m.group(1) in keep:
            write = True
        else:
            write = False
    if write:
        out_f.write(line)
f.close()
out_f.close()
